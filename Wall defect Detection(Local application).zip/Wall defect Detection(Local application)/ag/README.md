# Audio Analysis Server

## Setup

1.  **Install dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

## Running the Server

### Option 1: VS Code (Recommended)
1.  Open the "Run and Debug" side panel (Ctrl+Shift+D).
2.  Select "Python: Run Server" from the dropdown.
3.  Press F5 or click the green play button.
4.  Open [http://localhost:8000](http://localhost:8000) in your browser.

### Option 2: Terminal
1.  Run the following command:
    ```bash
    uvicorn src.server:app --reload
    ```
2.  Open [http://localhost:8000](http://localhost:8000) in your browser.
