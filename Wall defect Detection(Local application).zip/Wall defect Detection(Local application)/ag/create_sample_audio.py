import wave
import struct
import math

def create_wav(filename="sample.wav"):
    sample_rate = 44100
    duration = 2.0
    frequency = 440.0

    print(f"Generating {filename}...")
    with wave.open(filename, 'w') as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        
        for i in range(int(sample_rate * duration)):
            value = int(32767.0 * math.sin(2.0 * math.pi * frequency * i / sample_rate))
            data = struct.pack('<h', value)
            wav_file.writeframesraw(data)
    print("Done.")

if __name__ == "__main__":
    create_wav()
