import requests

def test_ssr_api():
    url = "http://localhost:8000/upload"
    files = {'file': open('sample.wav', 'rb')}
    data = {'wall_type': 'hollow', 'tap_intensity': 'medium'}
    
    try:
        print("Sending SSR request...")
        response = requests.post(url, files=files, data=data)
        print(f"Status: {response.status_code}")
        
        content = response.text
        
        if "Analysis Results" in content:
            print("SUCCESS: HTML Template Rendered.")
            
            # Check for PDF logic
            if "jspdf" in content and "doc.save" in content:
                 print("  - PDF generation logic found (jsPDF).")
            else:
                 print("  - WARNING: PDF generation logic MISSING.")
                 
            # Basic sanity check of passed variables
            if "HOLLOW" in content or "SOLID" in content or "CRACK" in content:
                print("  - Context variables found.")
            else:
                print("  - WARNING: Context variables might be missing.")
        else:
            print("FAILURE: Did not find expected HTML content.")
            print("Full Response:", content)

    except Exception as e:
        print(f"ERROR: {e}")

if __name__ == "__main__":
    test_ssr_api()
