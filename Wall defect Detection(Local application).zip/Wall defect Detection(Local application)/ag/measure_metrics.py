
import pandas as pd
import time
import numpy as np
import os
import sys

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from model import create_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

def measure():
    print("Loading data...")
    # Adjust path if needed
    data_path = 'data/raw/data.csv'
    if not os.path.exists(data_path):
        # Try processed
        data_path = 'data/processed/train.csv'
    
    if not os.path.exists(data_path):
        print("Data file not found!")
        return

    df = pd.read_csv(data_path)
    print(f"Dataset Size: {len(df)} samples")

    # Assuming 'target' is the label
    if 'target' not in df.columns:
        # Fallback for raw data if target isn't named 'target'
        # Inspect columns
        print(f"Columns: {df.columns}")
        # Assuming last column is target for demo if not found
        target_col = df.columns[-1]
    else:
        target_col = 'target'
        
    X = df.drop(target_col, axis=1)
    y = df[target_col]
    
    # Simple split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = create_model()
    print("Training model...")
    model.fit(X_train, y_train)
    
    print("Measuring performance...")
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    f1 = f1_score(y_test, preds, average='weighted')
    
    print(f"Accuracy: {acc:.4f}")
    print(f"F1 Score: {f1:.4f}")
    
    print("Measuring latency...")
    start_time = time.time()
    n_loops = 1000
    for _ in range(n_loops):
        _ = model.predict(X_test.iloc[0:1])
    end_time = time.time()
    
    avg_latency_ms = ((end_time - start_time) / n_loops) * 1000
    print(f"Average Inference Latency: {avg_latency_ms:.4f} ms")

if __name__ == "__main__":
    measure()
