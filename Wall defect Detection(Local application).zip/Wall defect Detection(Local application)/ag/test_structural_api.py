import requests

def test_structural_api():
    url = "http://localhost:8000/upload"
    files = {'file': open('sample.wav', 'rb')}
    data = {'wall_type': 'hollow', 'tap_intensity': 'medium'}
    
    try:
        print("Sending request with config...")
        response = requests.post(url, files=files, data=data)
        print(f"Status: {response.status_code}")
        
        json_resp = response.json()
        print(f"Primary Defect: {json_resp.get('primary_defect')}")
        print(f"Anomaly Score: {json_resp.get('anomaly_score')}")
        print(f"Metrics: {json_resp.get('metrics')}")
        
        if response.status_code == 200 and 'primary_defect' in json_resp:
            print("SUCCESS: Structural API verified.")
        else:
            print("FAILURE: API returned error or missing data.")

    except Exception as e:
        print(f"ERROR: {e}")

if __name__ == "__main__":
    test_structural_api()
