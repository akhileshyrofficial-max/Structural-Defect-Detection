import requests

def test_api():
    url = "http://localhost:8000/upload"
    files = {'file': open('sample.wav', 'rb')}
    
    try:
        print("Sending request...")
        response = requests.post(url, files=files)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.json()}")
        if response.status_code == 200:
            print("SUCCESS: API verified.")
        else:
            print("FAILURE: API returned error.")
    except Exception as e:
        print(f"ERROR: {e}")

if __name__ == "__main__":
    test_api()
