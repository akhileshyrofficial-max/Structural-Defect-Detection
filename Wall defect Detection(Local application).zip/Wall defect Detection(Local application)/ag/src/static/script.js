const analyzeBtn = document.getElementById('analyze-btn');
const fileInput = document.getElementById('audio-file');
const resultsPanel = document.getElementById('results-panel');
const downloadActions = document.getElementById('download-actions');
const fileNameDisplay = document.getElementById('file-name-display');

// Config
const wallTypeSelect = document.getElementById('wall-type');
const tapIntensitySelect = document.getElementById('tap-intensity');

analyzeBtn.addEventListener('click', () => {
    // If no file, trigger file input
    if (fileInput.files.length === 0) {
        fileInput.click();
    } else {
        // File already selected, just upload
        handleUpload(fileInput.files[0]);
    }
});

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        const file = e.target.files[0];
        fileNameDisplay.textContent = `Selected: ${file.name}`;
        fileNameDisplay.classList.remove('hidden');
        analyzeBtn.textContent = "Start Analysis";

        // Auto-start or wait for user? Let's wait for specific click to start
    }
});

async function handleUpload(file) {
    // UI Loading State
    analyzeBtn.textContent = "Analyzing...";
    analyzeBtn.disabled = true;
    resultsPanel.classList.add('hidden');
    downloadActions.classList.add('hidden');

    const formData = new FormData();
    formData.append('file', file);
    formData.append('wall_type', wallTypeSelect.value);
    formData.append('tap_intensity', tapIntensitySelect.value);

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error("Analysis failed");

        const data = await response.json();
        renderStructuralResults(data);

    } catch (err) {
        alert("Error: " + err.message);
    } finally {
        analyzeBtn.textContent = "Analyze Audio";
        analyzeBtn.disabled = false;
    }
}

function renderStructuralResults(data) {
    resultsPanel.classList.remove('hidden');
    downloadActions.classList.remove('hidden');

    // Smooth scroll to results
    resultsPanel.scrollIntoView({ behavior: 'smooth' });

    // 1. Primary Defect Banner
    const banner = document.getElementById('primary-defect-banner');
    const defectName = document.getElementById('defect-name');
    const defectConf = document.getElementById('defect-confidence');
    const mainProgress = document.getElementById('main-progress');
    const anomalyScore = document.getElementById('anomaly-score');

    defectName.textContent = data.primary_defect;
    defectConf.textContent = data.confidence.toFixed(2) + '%';
    mainProgress.style.width = data.confidence + '%';
    anomalyScore.textContent = data.anomaly_score + '/100';

    // Banner styling logic
    banner.classList.remove('danger', 'success');
    if (data.primary_defect === 'SOLID') {
        banner.classList.add('success');
        defectName.style.color = 'var(--success)';
        mainProgress.style.background = 'var(--success)';
    } else {
        banner.classList.add('danger');
        defectName.style.color = 'var(--danger)';
        mainProgress.style.background = 'var(--danger)';
    }

    // 2. Probability Bars
    const probContainer = document.getElementById('prob-bars');
    probContainer.innerHTML = ''; // clear

    // Order: HOLLOW, SOLID, SEMI-HOLLOW, CRACK
    const order = ['HOLLOW', 'SOLID', 'SEMI-HOLLOW', 'CRACK'];

    order.forEach(cat => {
        const val = data.probabilities[cat] || 0;

        const item = document.createElement('div');
        item.className = 'prob-item';
        item.innerHTML = `
            <div class="prob-header">
                <span>${cat}</span>
                <span>${val}%</span>
            </div>
            <div class="prob-track">
                <div class="prob-fill" style="width: ${val}%; background: ${getColorForCat(cat)}"></div>
            </div>
        `;
        probContainer.appendChild(item);
    });

    // 3. Metrics
    document.getElementById('m-freq').textContent = data.metrics.frequency_hz + ' Hz';
    document.getElementById('m-dur').textContent = data.metrics.duration_sec + ' sec';
    document.getElementById('m-echo').textContent = data.metrics.ultrasonic_echo_us + ' µs';
    document.getElementById('m-depth').textContent = data.metrics.estimated_depth_cm + ' cm';

    // 4. Recommendation
    document.getElementById('recommendation-text').textContent = data.recommendation;

    // Save for download
    window.lastAnalysisData = data;
}

function getColorForCat(cat) {
    if (cat === 'SOLID') return '#10b981'; // green
    if (cat === 'HOLLOW') return '#ef4444'; // red
    if (cat === 'CRACK') return '#f59e0b'; // orange
    return '#3b82f6'; // blue
}

// Download Report Handler
document.querySelector('.download-btn').addEventListener('click', () => {
    if (!window.lastAnalysisData) {
        alert("Please run an analysis first.");
        return;
    }

    const data = window.lastAnalysisData;
    const date = new Date().toLocaleString();

    let report = `STRUCTURAL AUDIO ANALYSIS REPORT\n`;
    report += `Generated: ${date}\n`;
    report += `================================================\n\n`;

    report += `PRIMARY FINDING: ${data.primary_defect}\n`;
    report += `Confidence: ${data.confidence.toFixed(2)}%\n`;
    report += `Anomaly Score: ${data.anomaly_score}/100\n\n`;

    report += `METRICS\n`;
    report += `------------------------------------------------\n`;
    report += `Frequency: ${data.metrics.frequency_hz} Hz\n`;
    report += `Duration: ${data.metrics.duration_sec} sec\n`;
    report += `Ultrasonic Echo: ${data.metrics.ultrasonic_echo_us} \u00B5s\n`; // using unicode for micro symbol
    report += `Estimated Depth: ${data.metrics.estimated_depth_cm} cm\n\n`;

    report += `PROBABILITY DISTRIBUTION\n`;
    report += `------------------------------------------------\n`;
    for (const [key, val] of Object.entries(data.probabilities)) {
        report += `${key}: ${val}%\n`;
    }
    report += `\n`;

    report += `RECOMMENDATION\n`;
    report += `------------------------------------------------\n`;
    report += `${data.recommendation}\n`;

    // Create Blob and Download
    const blob = new Blob([report], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Analysis_Report_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
});
