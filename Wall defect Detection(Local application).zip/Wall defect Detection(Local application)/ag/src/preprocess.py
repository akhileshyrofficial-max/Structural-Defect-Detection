import pandas as pd
from sklearn.model_selection import train_test_split
import os

def preprocess_data():
    if not os.path.exists('data/raw/data.csv'):
        print("Raw data not found. Run acquire.py first.")
        return

    df = pd.read_csv('data/raw/data.csv')
    
    X = df.drop('target', axis=1)
    y = df['target']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Recombine for saving
    train_df = pd.concat([X_train, y_train], axis=1)
    test_df = pd.concat([X_test, y_test], axis=1)
    
    os.makedirs('data/processed', exist_ok=True)
    train_df.to_csv('data/processed/train.csv', index=False)
    test_df.to_csv('data/processed/test.csv', index=False)
    print("Data processed and saved to data/processed/")

if __name__ == "__main__":
    preprocess_data()
