from fastapi import FastAPI, File, UploadFile, Form, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import shutil
import os
from . import analyze_audio

import json

app = FastAPI()

# Create temp dir
os.makedirs("temp", exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory="src/static"), name="static")

# Mount templates
templates = Jinja2Templates(directory="src/templates")

@app.get("/", response_class=HTMLResponse)
async def read_index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/upload", response_class=HTMLResponse)
async def upload_audio(
    request: Request,
    file: UploadFile = File(...),
    wall_type: str = Form(...),
    tap_intensity: str = Form(...)
):
    temp_path = f"temp/{file.filename}"
    with open(temp_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    try:
        results = analyze_audio.analyze(temp_path)
        
        # Combine results with request context for text rendering
        context = {
            "request": request,
            "primary_defect": results["primary_defect"],
            "confidence": results["confidence"],
            "anomaly_score": results["anomaly_score"],
            "probabilities": results["probabilities"],
            "metrics": results["metrics"],
            "recommendation": results["recommendation"],
            "json_data": json.dumps(results)
        }
        
        return templates.TemplateResponse("index.html", context)
        
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

if __name__ == "__main__":
    import uvicorn
    print("Starting server at http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
