import pandas as pd
import joblib
from model import create_model
from sklearn.metrics import accuracy_score
import os
import acquire
import preprocess

def train_model():
    # Ensure data exists
    if not os.path.exists('data/processed/train.csv'):
        print("Processed data not found. Running pipeline...")
        acquire.get_data()
        preprocess.preprocess_data()

    train_df = pd.read_csv('data/processed/train.csv')
    test_df = pd.read_csv('data/processed/test.csv')

    X_train = train_df.drop('target', axis=1)
    y_train = train_df['target']
    X_test = test_df.drop('target', axis=1)
    y_test = test_df['target']

    model = create_model()
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    
    print(f"Model trained. Accuracy: {accuracy:.4f}")
    
    # Save predictions
    output_df = pd.DataFrame({'Actual': y_test, 'Predicted': predictions})
    output_df.to_csv('data/predictions.csv', index=False)
    print("Predictions saved to data/predictions.csv")
    
    joblib.dump(model, 'model.pkl')
    print("Model saved to model.pkl")

if __name__ == "__main__":
    train_model()
