import pandas as pd
from sklearn.datasets import make_classification
import os

def get_data():
    X, y = make_classification(n_samples=1000, n_features=20, n_classes=2, random_state=42)
    df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(20)])
    df['target'] = y
    
    os.makedirs('data/raw', exist_ok=True)
    df.to_csv('data/raw/data.csv', index=False)
    print("Data acquired and saved to data/raw/data.csv")

if __name__ == "__main__":
    get_data()
